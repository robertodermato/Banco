# Como usar o pacote

Crie uma pasta chamada indivíduos no diretório raiz e coloque lá as contas a serem criadas.
